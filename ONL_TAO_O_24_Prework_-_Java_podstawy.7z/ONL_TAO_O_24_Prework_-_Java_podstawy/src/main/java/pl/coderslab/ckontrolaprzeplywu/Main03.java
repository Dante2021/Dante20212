package pl.coderslab.ckontrolaprzeplywu;

public class Main03 {

	public static void main(String[] args) {

		for (int i = 0; i <= 5; i = i + 1) {
			System.out.println("Java");


	}

}}
