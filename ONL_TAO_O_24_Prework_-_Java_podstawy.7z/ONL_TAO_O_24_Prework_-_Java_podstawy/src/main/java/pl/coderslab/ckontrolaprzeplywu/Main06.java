package pl.coderslab.ckontrolaprzeplywu;

public class Main06 {

	public static void main(String[] args) {
		int x = 6;
		for (int z = 0; z <= x; z++) {
			System.out.print(z);
			if (z % 2 > 0) {
				System.out.print(" - nieparzysta\n");

			}else System.out.print(" - parzysta\n");
		}
		int y=0;
		while (y<=x){
			System.out.print(y);
			if (y % 2 > 0) {
				System.out.print(" - nieparzysta\n");

			}else System.out.print(" - parzysta\n");
			y++;
		}

	}

}
