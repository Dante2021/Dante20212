package pl.coderslab.ckontrolaprzeplywu;

public class Main05 {

	public static void main(String[] args) {
		int resultWhile=0;
		int resultFor = 0;
		for (int a = 1; a < 11; a++) {
			resultFor = resultFor + a; }
		int b = 0;
		while (b < 11) {
			resultWhile = resultWhile + b;
			b++;		}
		System.out.println(resultFor);
		System.out.println(resultWhile);
	}

}
