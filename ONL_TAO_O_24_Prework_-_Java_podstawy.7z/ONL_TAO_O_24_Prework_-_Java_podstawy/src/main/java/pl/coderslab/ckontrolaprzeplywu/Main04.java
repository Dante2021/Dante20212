package pl.coderslab.ckontrolaprzeplywu;

public class Main04 {

	public static void main(String[] args) {

		for (int i = 1; i <= 10; i = i + 1) {
			System.out.print( i + " ");
		} System.out.println();
		int i = 1 ;
			while (i <= 10 ) {
				System.out.print( i +" " );
				i++;




	}

}}

