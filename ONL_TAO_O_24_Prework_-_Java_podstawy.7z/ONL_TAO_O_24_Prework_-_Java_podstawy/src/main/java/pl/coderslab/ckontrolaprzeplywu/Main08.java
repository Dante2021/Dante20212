package pl.coderslab.ckontrolaprzeplywu;

public class Main08 {

    public static void main(String[] args) {
 int n = 5;
 for (int i = 0; i < n; i++) {
        String row = "";
        for (int x = 0; x < n; x++) {
            if (x<=i) {row += "*";}
            else {row += x+1;}
        }
        System.out.print(row + "\n");
}}}
