package pl.coderslab.ckontrolaprzeplywu;

public class Main10 {

    public static void main(String[] args) {

        int n = 5;


        for (int i = 0; i < n*2; i++) {
            String row = "";

            for (int x = 0; x < n; x++) {

                if (x<=i && i<=n) {row += "*";}
                else if (x+i<2*n && i>n) {row += "*";}

                else {row += x+1;}
            }
            System.out.print(row + "\n");



        }
    }

}
