package pl.coderslab.apierwszyprogram;

public class Main02{

public static void main(String[] args) {
    System.out.println("Hello Java");
    System.out.println("Hello Coderslab");
}}