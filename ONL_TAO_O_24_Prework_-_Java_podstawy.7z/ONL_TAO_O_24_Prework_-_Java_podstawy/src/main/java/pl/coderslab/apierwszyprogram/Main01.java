package pl.coderslab.apierwszyprogram;

public class Main01 {

    public static void main(String[] args) {
        System.out.print("Hello World");
    }
}
