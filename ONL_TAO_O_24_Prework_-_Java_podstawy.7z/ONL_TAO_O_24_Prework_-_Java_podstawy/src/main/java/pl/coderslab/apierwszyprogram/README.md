![Coders-Lab-1920px-no-background](https://user-images.githubusercontent.com/152855/73064373-5ed69780-3ea1-11ea-8a71-3d370a5e7dd8.png)


Pamiętaj, aby rozwiązania do zadań umieszczać w odpowiednich plikach `java`, przygotowanych do zadań.  

## Zadanie 1

W pliku `Main01.java` w metodzie `main` wypisz na konsoli napis:
`Hello world`.

## Zadanie 2

W pliku `Main02.java` utwórz metodę `main`, a następnie wypisz w oddzielnych liniach:
````plaintext
Hello Java
Hello Coderslab
````

## Zadanie 3

Zmodyfikuj plik `Main03.java` tak, aby wynik jego wykonania był następujący: 
```plaintext
Dzisiaj zaczynam kurs
JAVA
w CodersLab
```
Nie modyfikuj zawartych w pliku napisów.

## Zadanie 4

W pliku `Main04.java` zakomentuj odpowiednie linie tak, aby otrzymać następujący wynik:
 ```
   J    a   v     v  a 
   J   a a   v   v  a a
J  J  aaaaa   V V  aaaaa
 JJ  a     a   V  a     a
 ```

## Zadanie 5

W pliku `Main05.java` został popełniony błąd,
usuń komentarz z lini 6:
````
//		System.out.println("Hello world")
````

## Zadanie 6

W pliku `Main06.java` został popełniony błąd,
usuń komentarz z lini 6:
````
//		System.out.prinln("Hello world");
````
dokonaj poprawek, wymaganych do poprawnego działania.

