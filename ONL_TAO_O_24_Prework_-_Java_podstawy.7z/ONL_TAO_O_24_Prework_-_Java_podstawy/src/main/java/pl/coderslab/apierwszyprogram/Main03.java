package pl.coderslab.apierwszyprogram;

public class Main03 {

	public static void main(String[] args) {
		System.out.println("Dzisiaj zaczynam kurs");
		System.out.println("JAVA");
		System.out.println("w CodersLab");

	}

}
