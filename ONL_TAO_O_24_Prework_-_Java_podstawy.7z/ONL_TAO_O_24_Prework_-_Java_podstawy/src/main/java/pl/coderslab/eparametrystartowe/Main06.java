package pl.coderslab.eparametrystartowe;

public class Main06 {

    public static void main(String[] args) {
        int n=Integer.parseInt(args[0]);

        for (int i=1;i<n+1;i++){

            int a=i;
            for (int b=1;b<n+1;b++){

                int c=a*b;
                System.out.println(a+" x "+b+" = "+c);
            }
            System.out.println();


        }

    }

}
