package pl.coderslab.eparametrystartowe;

public class Main03 {
    public static void main(String[] args) {

        double mean = 0;
        for (int i = 0; i < args.length; i++) {
            mean=mean+Integer.parseInt(args[i]);

        }

        System.out.print(mean/args.length);

    }
}
