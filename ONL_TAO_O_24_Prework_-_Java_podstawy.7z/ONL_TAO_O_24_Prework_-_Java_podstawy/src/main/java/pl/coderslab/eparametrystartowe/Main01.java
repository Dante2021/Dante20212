package pl.coderslab.eparametrystartowe;

public class Main01 {
    public static void main(String[] args) {
        for (int a = 0; a < args.length; a++) {
            System.out.print(args[a] + " ");
    }
}}
