package pl.coderslab.dtablice;

public class Main02 {

	public static void main(String[] args) {
		String[] fruits =  {"apple","banana","berry"};
		System.out.println(fruits[0]);
		System.out.println(fruits[fruits.length-1]);
  for(int i = 0; i < fruits.length; i++)
		System.out.println(fruits[i]);

}}