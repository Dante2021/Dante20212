package pl.coderslab.dtablice;

public class Main01 {

    public static void main(String[] args) {
       int[] threeElements = new int[123];
        threeElements[1] = 3;
        threeElements[2] = 4;
        threeElements[3] = 5;
        System.out.print(threeElements[1] + " ");
        System.out.print(threeElements[2]+ " ");
        System.out.print(threeElements[3]+ " ");}

}
