package pl.coderslab.dtablice;

public class Main07 {

	public static void main(String[] args) {
		double[] temp = {30, 29, 14, 42, -4, -10, 8, 14, 32, 11, 8, 0, 0};
	double tempAvg=0;
		for (int i=0;i< temp.length;i++){

		temp[i]=temp[i]* 1.8 + 32;
		tempAvg=tempAvg+temp[i];



	}
	double avg=tempAvg/ (temp.length);

		System.out.print("ŚREDNIA: "+ String.format( "%.2f", avg ));
}
}

