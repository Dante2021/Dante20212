package pl.coderslab.dtablice;

public class Main06 {

	public static void main(String[] args) {
		int[] numbers = {4, 643, 112, 9999, -69};
		for (int i=numbers.length-1;i>-1;i--){
			System.out.println(numbers[i]);

	}

}}