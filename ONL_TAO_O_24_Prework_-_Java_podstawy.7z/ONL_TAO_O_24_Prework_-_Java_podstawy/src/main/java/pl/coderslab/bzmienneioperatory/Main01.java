package pl.coderslab.bzmienneioperatory;

public class Main01 {

	public static void main(String[] args) {
		int int1 = 10 ;
		char char2 = 34 ;
				long long3 = 2;
						double double4 = 3;
						boolean boolean5 = true ;


	}

}
