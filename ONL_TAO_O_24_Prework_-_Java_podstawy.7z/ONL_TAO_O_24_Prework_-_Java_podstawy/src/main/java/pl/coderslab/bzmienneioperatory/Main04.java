package pl.coderslab.bzmienneioperatory;

public class Main04 {

	public static void main(String[] args) {
		String str1 = "Kurs";
		String str2 = "Java";
		String joinedStrings = str1 + " " + str2;
		System.out.println(joinedStrings);

	}

}
