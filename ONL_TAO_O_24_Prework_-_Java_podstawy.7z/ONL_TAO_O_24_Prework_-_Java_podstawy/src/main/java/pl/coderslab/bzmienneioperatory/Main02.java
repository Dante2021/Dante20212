package pl.coderslab.bzmienneioperatory;

public class Main02 {

	public static void main(String[] args) {
		byte nr1 = 94;
		short nr2 = 257;
		int result = nr1 + nr2;
		System.out.println(result);

	}

}
