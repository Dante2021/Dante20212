package pl.coderslab.bzmienneioperatory;

public class Main03 {

	public static void main(String[] args) {
		int nr1 = 5;
		int nr2 = 3;
		int result = nr1%nr2;
		System.out.println(result);

	}

}
