package pl.coderslab.bzmienneioperatory;

public class Main05 {

	public static void main(String[] args) {
		double nr1 =  5.1;
		float nr2 = 5.0f;
		boolean result = nr1>nr2;
		System.out.println(result);

	}

}
